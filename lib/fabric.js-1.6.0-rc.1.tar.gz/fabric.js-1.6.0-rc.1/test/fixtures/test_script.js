(function(){
  // set global variable
  this.foo = 'bar';
  this.window = undefined;
  this.document = undefined;

})();